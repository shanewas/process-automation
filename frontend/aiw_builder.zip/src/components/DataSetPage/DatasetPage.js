import React, { Component } from "react";
import Navbarup from "../navBar/Navbarup";

export default class DatasetPage extends Component {
  render() {
    return (
      <div>
        <Navbarup></Navbarup>
        <h1>Omar you make this Component </h1>
      </div>
    );
  }
}
