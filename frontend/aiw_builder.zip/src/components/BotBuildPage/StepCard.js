import React from "react";
import { makeStyles, Box, Typography, IconButton } from "@material-ui/core";
import {
  LinkRounded as LinkIcon,
  MouseRounded as MouseIcon,
  MoreHoriz as MenuIcon,
  FolderRounded as LoadIcon,
  KeyboardHideRounded as PressedIcon,
  CameraAltRounded as CameraIcon,
} from "@material-ui/icons";

const type = {
  link: {
    Icon: LinkIcon,
    color: "#6AD9C4",
    bgcolor: "rgba(106, 217, 196, 0.15)",
  },
  click: {
    Icon: MouseIcon,
    color: "#F9DB6D",
    bgcolor: "rgba(249, 219, 109, 0.15)",
  },
  LoadData: {
    Icon: LoadIcon,
    color: "#FEA042",
    bgcolor: "rgba(254, 160, 66, 0.15)",
  },
  KeyBoard: {
    Icon: PressedIcon,
    color: "#FE426F",
    bgcolor: "rgba(254, 66, 111, 0.15)",
  },
  ScreenShot: {
    Icon: CameraIcon,
    color: "#FE42C9",
    bgcolor: "rgba(254, 66, 201, 0.15)",
  },
};

const useStyles = makeStyles((theme) => ({
  stepWrapper: (props) => ({
    "&-step": {
      width: "80%",
      borderRadius: theme.spacing(1),
      padding: theme.spacing(2),
      display: "flex",
      backgroundColor: theme.palette.background.paper,
      transition: ".3s",
      cursor: "pointer",
      border: ".8px solid rgba(0,0,0,0)",
      borderColor: props.selected ? props.color : "rgba(0,0,0,0)",
      transform: props.selected ? "scale(1.05)" : "scale(1)",
    },

    "&-indicator": {
      height: "20px",
      width: "20px",
      borderRadius: "50px",
      border: `1px solid ${props.color}`,
      transition: ".3s",
    },

    "&:hover &-step": {
      border: `.8px solid ${props.color}`,
    },

    "&:hover &-indicator": {
      background: props.color,
      boxShadow: `0px 1px 10px ${props.color}`,
    },
  }),

  icon: {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    marginRight: theme.spacing(2),
    height: "50px",
    width: "50px",
    color: (props) => props.color,
    borderRadius: "50%",
    background: (props) => props.bgcolor,
  },
}));

export default (props) => {
  console.log(props);
  const { color, bgcolor, Icon } = type[props._type];
  const classes = useStyles({
    selected: props.selected,
    color,
    bgcolor,
  });

  return (
    <Box
      mb={3}
      display="flex"
      alignItems="center"
      justifyContent="space-around"
      className={classes.stepWrapper}
    >
      <Box className={`${classes.stepWrapper}-indicator`}>
        <Box className={classes.line} />
      </Box>
      <Box
        onClick={() => props.selectStep(props.idx)}
        onMouseLeave={(e) => props.selectStep("")}
        className={`${classes.stepWrapper}-step`}
      >
        <Box className={classes.icon}>
          <Icon />
        </Box>
        <Box>
          <Typography variant="h6">{props.title}</Typography>
          <Typography>{props.text}</Typography>
        </Box>
      </Box>
      <IconButton onClick={props.openMenu}>
        <MenuIcon />
      </IconButton>
    </Box>
  );
};
