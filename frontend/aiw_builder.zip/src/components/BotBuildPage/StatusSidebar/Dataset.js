import React from "react";
import { Box, Button, Typography } from "@material-ui/core";

export default (props) => {
  return (
    <Box mt={5} textAlign="center">
      <img src="/assets/images/csv.svg" alt="Csv" />
      <Box my={2}>
        <Typography variant="h6">Create a Dataset Schema</Typography>
      </Box>
      <Button variant="outlined" color="secondary">
        Add CSV
      </Button>
    </Box>
  );
};
