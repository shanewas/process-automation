import React from "react";
import { Box, makeStyles } from "@material-ui/core";

const variables = [
  {
    id: 1,
    name: "username",
  },
  {
    id: 2,
    name: "age",
  },
];

const useStyles = makeStyles((theme) => ({
  variable: {
    fontFamily: "Fira Code",
    fontWeight: 500,
    color: theme.palette.secondary.main,
    padding: theme.spacing(2),
    backgroundColor: "#000",
    marginBottom: theme.spacing(2),
    transition: ".3s",
    borderRadius: theme.spacing(0.5),
    cursor: "pointer",

    "&:hover": {
      boxShadow: "0px 0px 10px rgba(116, 227, 206, 0.55)",
    },
    "&:active": {
      boxShadow: "0px 0px 20px rgba(116, 227, 206, 0.75)",
    },
  },
}));

export default (props) => {
  const classes = useStyles();
  return (
    <Box>
      {variables.map((variable) => (
        <Box key={variable.id} className={classes.variable}>
          {"{{"} {variable.name} {"}}"}
        </Box>
      ))}
    </Box>
  );
};
