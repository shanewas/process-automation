import React, { useState, useContext } from "react";
import StepCard from "./StepCard";
import {
  Box,
  ListItem,
  ListItemIcon,
  Menu,
  Typography,
} from "@material-ui/core";
import {
  RemoveCircle as RemoveIcon,
  EditRounded as EditIcon,
  AlbumRounded as RecordIcon,
} from "@material-ui/icons";
import { useDispatch, useSelector } from "react-redux";
import {
  editProcessAction,
  newProcessAction,
  removeStepAction,
} from "../../Store/actions";
import { ModalContext } from "../../context/ModalContext";
import generateStepObject from "./utils/generateStepObject";

const initStepMenu = {
  anchorEl: null,
  idx: null,
};
export default (props) => {
  const [stepMenu, setStepMenu] = useState(initStepMenu);
  const { setCurrentModal } = useContext(ModalContext);
  const dispatch = useDispatch();
  const steps = useSelector((state) => state.process);
  const variables = useSelector((state) => state.variables);
  const headers = useSelector((state) => state.headers);

  const openMenuHandler = (e, idx) => setStepMenu({ anchorEl: e.target, idx });

  const openProcessConfigModal = () =>
    setCurrentModal({
      name: "ProcessConfigModal",
      props: {
        editStep: (process) => {
          const newProcess = generateStepObject(process);
          dispatch(editProcessAction(newProcess, stepMenu.idx));
          setStepMenu(initStepMenu);
        },
        currentStep: steps[stepMenu.idx],
        variables: variables,
        headers: headers,
      },
    });

  const removeStep = () => {
    dispatch(removeStepAction(stepMenu.idx));
    setStepMenu(initStepMenu);
  };

  return (
    <>
      {props.steps.length ? (
        props.steps.map((step, idx) => (
          <StepCard
            selected={props.selectedStep === idx}
            selectStep={props.selectStep}
            selectedStep={props.selectedStep}
            openMenu={(e) => openMenuHandler(e, idx)}
            idx={idx}
            key={step.id}
            {...step}
          />
        ))
      ) : (
        <Box textAlign="center">
          <Typography variant="h6">
            Enter a URL and start recording steps
          </Typography>
        </Box>
      )}
      <Menu
        onClose={() => setStepMenu(initStepMenu)}
        open={Boolean(stepMenu.anchorEl)}
        anchorEl={stepMenu.anchorEl}
      >
        <ListItem button onClick={openProcessConfigModal}>
          <ListItemIcon>
            <EditIcon />
          </ListItemIcon>
          Edit Step
        </ListItem>
        <ListItem button onClick={removeStep}>
          <ListItemIcon>
            <RemoveIcon />
          </ListItemIcon>
          Remove Step
        </ListItem>
      </Menu>
    </>
  );
};
