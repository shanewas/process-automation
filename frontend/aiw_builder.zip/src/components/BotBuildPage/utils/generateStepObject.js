export default (process) => {
  switch (process._type) {
    case "link":
      return {
        _type: process._type,
        title: "Link",
        text: `Opened link ${process.link}`,
        ...process,
      };
    case "click":
      return {
        _type: process._type,
        title: "Clicked",
        text: `Clicked on a '${process.tagName}'`,
        ...process,
      };
    case "LoadData":
      return {
        _type: process._type,
        title: "Load Data",
        text: `Load data to ${process.tagName}`,
        ...process,
      };
    case "KeyBoard":
      return {
        _type: process._type,
        title: "Key Pressed",
        text: `'${process.value}' key Pressed`,
        ...process,
      };
  }
};
